package com.example.whatsappreporter

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val green = Color.rgb(22, 140, 85)
    private lateinit var phone: EditText
    private lateinit var reason: Spinner
    private lateinit var details: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 94, 61)
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(22), dp(24), dp(22), dp(20))
            setBackgroundColor(Color.rgb(246, 249, 247))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "WhatsApp Reporter"
            textSize = 25f
            setTextColor(Color.rgb(7, 94, 61))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "تجهيز بلاغ واضح لمراجعته ومشاركته"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        }
        content.addView(subtitle, matchWrap())

        addLabel(content, "رقم الهاتف مع مفتاح الدولة")
        phone = EditText(this).apply {
            hint = "+201xxxxxxxxx"
            textSize = 16f
            inputType = 3
            setSingleLine(true)
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT
        }
        styleInput(phone)
        content.addView(phone, matchWrap())

        addLabel(content, "سبب البلاغ")
        reason = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("رسائل مزعجة أو ترويجية", "احتيال أو نصب", "إساءة أو تهديد", "حساب وهمي أو انتحال شخصية", "خطاب كراهية أو تمييز"))
        }
        styleInput(reason)
        content.addView(reason, matchWrap())

        addLabel(content, "تفاصيل إضافية (اختياري)")
        details = EditText(this).apply {
            hint = "اكتب وصفاً مختصراً لما حدث، بدون مشاركة بياناتك السرية"
            textSize = 15f
            minLines = 4
            gravity = Gravity.TOP or Gravity.RIGHT
        }
        styleInput(details)
        content.addView(details, matchWrap())

        val note = TextView(this).apply {
            text = "تنبيه: التطبيق لا يرسل البلاغ تلقائياً ولا يضمن اتخاذ إجراء. راجع صحة المعلومات ثم شارك البلاغ بنفسك عبر القناة الرسمية المناسبة. لا تدخل كلمة مرور بريدك الإلكتروني هنا."
            textSize = 13f
            setTextColor(Color.rgb(90, 98, 94))
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        content.addView(note, matchWrap())

        val review = Button(this).apply {
            text = "مراجعة البلاغ"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = rounded(green, 12)
            setOnClickListener { reviewReport() }
        }
        val share = Button(this).apply {
            text = "مشاركة نص البلاغ"
            isAllCaps = false
            textSize = 16f
            setTextColor(green)
            background = rounded(Color.rgb(225, 241, 232), 12)
            setOnClickListener { shareReport() }
        }
        content.addView(review, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(8) })
        content.addView(share, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(10) })
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun reviewReport() {
        val number = phone.text.toString().trim()
        if (!Regex("^\\+[0-9]{8,15}$").matches(number)) {
            phone.error = "اكتب الرقم بصيغة دولية مثل +201xxxxxxxxx"
            return
        }
        AlertDialog.Builder(this)
            .setTitle("مراجعة البلاغ")
            .setMessage(reportText())
            .setPositiveButton("موافق") { _, _ -> shareReport() }
            .setNegativeButton("رجوع", null)
            .show()
    }

    private fun shareReport() {
        val number = phone.text.toString().trim()
        if (!Regex("^\\+[0-9]{8,15}$").matches(number)) {
            phone.error = "اكتب الرقم بصيغة دولية مثل +201xxxxxxxxx"
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "بلاغ عن حساب واتساب")
            putExtra(Intent.EXTRA_TEXT, reportText())
        }
        startActivity(Intent.createChooser(intent, "مشاركة البلاغ"))
    }

    private fun reportText(): String = """بلاغ عن حساب واتساب

رقم الهاتف المبلغ عنه: ${phone.text.toString().trim()}
سبب البلاغ: ${reason.selectedItem}
التفاصيل: ${details.text.toString().trim().ifBlank { "لا توجد تفاصيل إضافية" }}

أرجو مراجعة البلاغ والتحقق من المعلومات واتخاذ الإجراء المناسب إن ثبتت المخالفة.

ملاحظة: هذا النص أعدّه المستخدم ويجب مراجعته قبل إرساله."""

    private fun addLabel(parent: LinearLayout, value: String) {
        parent.addView(TextView(this).apply {
            text = value
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(40, 54, 46))
            setPadding(0, dp(12), 0, dp(7))
        }, matchWrap())
    }

    private fun styleInput(view: View) {
        view.background = rounded(Color.WHITE, 10)
        view.setPadding(dp(12), dp(10), dp(12), dp(10))
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
